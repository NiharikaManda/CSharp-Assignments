﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBAccess.DBAccessOperations
{
   public class SoftwarePackageOperations
    {
        public List<SoftwarePackage> GetAllSoftwarePackages()
        {
            using (TestEventDBEntities entities = new TestEventDBEntities())
            {
                return entities.Set<SoftwarePackage>().ToList();
            }
        }
    }
}
