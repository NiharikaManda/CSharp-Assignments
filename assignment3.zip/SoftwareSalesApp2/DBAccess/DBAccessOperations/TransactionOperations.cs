﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBAccess.DBAccessOperations
{
  public  class TransactionOperations
    {
        public List<Transaction> GetAllTransactions()
        {
            using (TestEventDBEntities entities = new TestEventDBEntities())
            {
                return entities.Set<Transaction>().Include("SoftwarePackage").ToList();
            }
        }

        public Transaction GetTransactionById(int id)
        {
            using (TestEventDBEntities entities = new TestEventDBEntities())
            {
                return entities.Set<Transaction>().Include("SoftwarePackage").Where(t => t.TransactionID == id).FirstOrDefault();
            }
        }
        public int AddTransaction(Transaction record)
        {

            using (TestEventDBEntities entities = new TestEventDBEntities())
            {
                entities.Transactions.Add(record);
                return entities.SaveChanges();
            }
            //  return 0;
        }
        public int UpDateTransaction(Transaction record)
        {

            using (TestEventDBEntities entities = new TestEventDBEntities())
            {
                var _record = entities.Transactions.FirstOrDefault(t => t.TransactionID == record.TransactionID);

                if (record != null)
                {
                    entities.Entry(record).State = System.Data.Entity.EntityState.Modified;
                }
                else
                {
                    throw new Exception("No Record found with Transaction Id " + record.TransactionID);
                }
                return entities.SaveChanges();
            }
            //  return 0;
        }
        public int DeleteTransaction(int id)
        {

            using (TestEventDBEntities entities = new TestEventDBEntities())
            {
                var _record = entities.Transactions.FirstOrDefault(t => t.TransactionID == id);

                if (_record != null)
                {
                    entities.Transactions.Remove(_record);// = System.Data.Entity.EntityState.Modified;
                }
                else
                {
                    throw new Exception("No Record found with Transaction Id " + id);
                }
                return entities.SaveChanges();
            }
            //  return 0;
        }
    }
}
