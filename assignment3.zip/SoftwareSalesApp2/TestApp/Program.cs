﻿using DBAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //using (SoftwareSalesAppDBEntities entities = new SoftwareSalesAppDBEntities())
            //{
            //    var abc= entities.Set<Transaction>().ToList();
            //}
          //  Constents obj = new Constents();
          //  var abc = obj.getAll();
        }
    }
}
