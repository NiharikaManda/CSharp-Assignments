﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Model
{
   public class TransactionModel
    {
        public int TransactionID { get; set; }
        public string CustomerName { get; set; }
        public int NumberOfLicenses { get; set; }
        public int SoftwarePackageID { get; set; }
        public string SoftwarePackageName { get; set; }
        public bool IsSetupRequired { get; set; }
        public DateTime? SetupDate { get; set; }
        public int SetupFee { get; set; }
        public int TotalCharges { get; set; }
        public int Charges { get; set; }

    }
}
