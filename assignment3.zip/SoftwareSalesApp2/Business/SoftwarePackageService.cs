﻿using Business.Model;
using DBAccess.DBAccessOperations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
 public   class SoftwarePackageService
    {
        public List<SoftwarePackageModel> GetAllSoftwarePackages()
        {
            List<SoftwarePackageModel> list = new List<SoftwarePackageModel>();
            SoftwarePackageOperations operation = new SoftwarePackageOperations();
            var dbList = operation.GetAllSoftwarePackages();

            foreach(var record in dbList)
            {
                list.Add(new SoftwarePackageModel()
                {
                    PackageName = record.PackageName,
                    Price = record.Price,
                    SoftwarePackageID = record.SoftwarePackageID
                });
            }

            return list;
        }
    }
}
