﻿using Business.Model;
using DBAccess;
using DBAccess.DBAccessOperations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business
{
    public class TransactionService
    {
        public List<TransactionModel> GetAllTransactions()
        {
            List<TransactionModel> List = new List<TransactionModel>();
            TransactionOperations trans = new TransactionOperations();
            var _list=trans.GetAllTransactions();
            foreach(var record in _list)
            {
                var _rec = new TransactionModel()
                {
                    TransactionID=record.TransactionID,
                    CustomerName = record.CustomerName,
                    SoftwarePackageID = record.SoftwarePackageID,
                    IsSetupRequired = record.IsSetupRequired,
                    NumberOfLicenses = record.NumberOfLicenses,
                    SetupDate = record.SetupDate.HasValue ? record.SetupDate : null,
                    SoftwarePackageName = record.SoftwarePackage.PackageName,
                    SetupFee= Constents.SetUpFee

                };

                _rec.Charges = record.SoftwarePackage.Price * record.NumberOfLicenses;
                if(record.IsSetupRequired)
                _rec.TotalCharges = record.NumberOfLicenses*500 + _rec.Charges;
                List.Add(_rec);

               
            }
            return List;
        }

        public TransactionModel GetTransactionById(int id)
        {
            TransactionOperations trans = new TransactionOperations();
            var record = trans.GetTransactionById(id);
            
                var _rec = new TransactionModel()
                {
                    CustomerName = record.CustomerName,
                    SoftwarePackageID = record.SoftwarePackageID,
                    IsSetupRequired = record.IsSetupRequired,
                    NumberOfLicenses = record.NumberOfLicenses,
                    SetupDate = record.SetupDate.HasValue ? record.SetupDate : null,
                    SoftwarePackageName = record.SoftwarePackage.PackageName,
                    SetupFee = Constents.SetUpFee

                };

                _rec.Charges = record.SoftwarePackage.Price * record.NumberOfLicenses;
                if (record.IsSetupRequired)
                    _rec.TotalCharges = record.NumberOfLicenses * 500 + _rec.Charges;
               // List.Add(_rec);


            
            return _rec;
        }


        public int SaveTransaction(TransactionModel record)
        {
            TransactionOperations trans = new TransactionOperations();
            Transaction _record = new Transaction()
            {
                CustomerName = record.CustomerName,
                SoftwarePackageID = record.SoftwarePackageID,
                IsSetupRequired = record.IsSetupRequired,
                NumberOfLicenses = record.NumberOfLicenses,
                SetupDate = record.SetupDate,

            };

            if (record.TransactionID == 0)
                return trans.AddTransaction(_record);
            else
            {
                _record.TransactionID = record.TransactionID;
                return trans.UpDateTransaction(_record);
            }
        }

        public int DeleteTransaction(int id)
        {

             TransactionOperations trans = new TransactionOperations();
            return trans.DeleteTransaction(id);
        }

    }
}
