﻿using Business;
using Business.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoftwareSalesApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            SoftwarePackageList.DataSource = new SoftwarePackageService().GetAllSoftwarePackages();
            SoftwarePackageList.DisplayMember = "PackageName";
            SoftwarePackageList.ValueMember = "SoftwarePackageID";

            SetupDateTime.Visible = false;
        }

        private void DisplaySales_Click(object sender, EventArgs e)
        {
            OutPutList.Items.Clear();
            TransactionService service = new TransactionService();
            var sales = service.GetAllTransactions();
            int index = 0;
            foreach (var sale in sales)
            {
                OutPutList.Items.Add("----------------  Sale " + (++index) + " -----------------");
                OutPutList.Items.Add("Transaction Id : " + sale.TransactionID);

                OutPutList.Items.Add("customer name : " + sale.CustomerName);
                OutPutList.Items.Add("software package : " + sale.SoftwarePackageName);
                OutPutList.Items.Add("charge : " + sale.Charges);
                OutPutList.Items.Add("setup Option : " + sale.IsSetupRequired);
                OutPutList.Items.Add("total charge : " + sale.ToString());
                OutPutList.Items.Add("Date of SetUp : " + sale.SetupDate);
                OutPutList.Items.Add("SetUp Fee : " + sale.SetupFee);


                OutPutList.Items.Add("");
            }
        }

        private void ProcessSaleBtn_Click(object sender, EventArgs e)
        {

            string selectedPak = SoftwarePackageList.GetItemText(SoftwarePackageList.SelectedItem);

            var softwareSale = new TransactionModel();
            softwareSale.CustomerName = CustomerNameTxt.Text;
            softwareSale.IsSetupRequired = AddSetupCheck.Checked;
            softwareSale.NumberOfLicenses = Convert.ToInt32(NoOfLicensesTxt.Text);
            softwareSale.SoftwarePackageID = Convert.ToInt32(SoftwarePackageList.SelectedValue);

            if (softwareSale.IsSetupRequired)
            {
                softwareSale.SetupDate = SetupDateTime.Value;
            }
            TransactionService service = new TransactionService();
            int result = service.SaveTransaction(softwareSale);
            if (result > 0)
            {
                MessageBox.Show("Record added sucessfuly");
            }

        }

        private void GetSoftwareSale_Click(object sender, EventArgs e)
        {
            OutPutList.Items.Clear();
            TransactionService service = new TransactionService();
            var sale = service.GetTransactionById(Convert.ToInt32(SoftwareSaleIdTxt.Text));


            OutPutList.Items.Add("----------------  Sale -----------------");

            OutPutList.Items.Add("customer name : " + sale.CustomerName);
            OutPutList.Items.Add("software package : " + sale.SoftwarePackageName);
            OutPutList.Items.Add("charge : " + sale.Charges);
            OutPutList.Items.Add("setup Option : " + sale.IsSetupRequired);
            OutPutList.Items.Add("total charge : " + sale.ToString());
            OutPutList.Items.Add("Date of SetUp : " + sale.SetupDate);
            OutPutList.Items.Add("SetUp Fee : " + sale.SetupFee);


            OutPutList.Items.Add("");
        }

        private void UpdateSoftwareSale_Click(object sender, EventArgs e)
        {
            OutPutList.Items.Clear();
            TransactionService service = new TransactionService();
            var sale = service.GetTransactionById(Convert.ToInt32(UpdateSoftwareSaleIdTxt.Text));
            CustomerNameTxt.Text = sale.CustomerName;
            NoOfLicensesTxt.Text = sale.NumberOfLicenses.ToString();
            AddSetupCheck.Checked = sale.IsSetupRequired;
            if (sale.IsSetupRequired)
            {
                SetupDateTime.Visible = AddSetupCheck.Checked;
                SetupDateTime.Value = sale.SetupDate.Value;
            }

            foreach (SoftwarePackageModel cbi in SoftwarePackageList.Items)
            {
                if (cbi.SoftwarePackageID == sale.SoftwarePackageID)
                {
                    SoftwarePackageList.SelectedItem = cbi;
                    break;
                }
            }
        }

        private void AddSetupCheck_CheckedChanged(object sender, EventArgs e)
        {
            SetupDateTime.Visible = AddSetupCheck.Checked;
        }

        private void DeleteSoftwareSale_Click(object sender, EventArgs e)
        {
            TransactionService service = new TransactionService();

           var result= service.DeleteTransaction(Convert.ToInt32(SoftwareSaleIdTxt.Text));
            if (result > 0)
            {
                MessageBox.Show("Record Deleted sucessfuly");
            }
        }

        private void SoftwarePackageList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void OutPutList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AddSetupRadio_CheckedChanged(object sender, EventArgs e)
        {
            SetupDateTime.Visible = AddSetupRadio.Checked;
        }
    }
}
