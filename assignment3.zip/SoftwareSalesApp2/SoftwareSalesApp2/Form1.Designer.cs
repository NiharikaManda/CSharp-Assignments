﻿namespace SoftwareSalesApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DisplaySales = new System.Windows.Forms.Button();
            this.CustomerNameTxt = new System.Windows.Forms.TextBox();
            this.NoOfLicensesTxt = new System.Windows.Forms.TextBox();
            this.AddSetupCheck = new System.Windows.Forms.CheckBox();
            this.SetupDateTime = new System.Windows.Forms.DateTimePicker();
            this.ProcessSaleBtn = new System.Windows.Forms.Button();
            this.SoftwarePackageList = new System.Windows.Forms.ComboBox();
            this.OutPutList = new System.Windows.Forms.ListBox();
            this.SoftwareSaleIdTxt = new System.Windows.Forms.TextBox();
            this.GetSoftwareSale = new System.Windows.Forms.Button();
            this.DeleteSoftwareSale = new System.Windows.Forms.Button();
            this.UpdateSoftwareSale = new System.Windows.Forms.Button();
            this.UpdateSoftwareSaleIdTxt = new System.Windows.Forms.TextBox();
            this.AddSetupRadio = new System.Windows.Forms.RadioButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // DisplaySales
            // 
            this.DisplaySales.Location = new System.Drawing.Point(404, 375);
            this.DisplaySales.Name = "DisplaySales";
            this.DisplaySales.Size = new System.Drawing.Size(121, 23);
            this.DisplaySales.TabIndex = 1;
            this.DisplaySales.Text = "Display Sales";
            this.DisplaySales.UseVisualStyleBackColor = true;
            this.DisplaySales.Click += new System.EventHandler(this.DisplaySales_Click);
            // 
            // CustomerNameTxt
            // 
            this.CustomerNameTxt.Location = new System.Drawing.Point(44, 82);
            this.CustomerNameTxt.Name = "CustomerNameTxt";
            this.CustomerNameTxt.Size = new System.Drawing.Size(100, 20);
            this.CustomerNameTxt.TabIndex = 2;
            // 
            // NoOfLicensesTxt
            // 
            this.NoOfLicensesTxt.Location = new System.Drawing.Point(45, 122);
            this.NoOfLicensesTxt.Name = "NoOfLicensesTxt";
            this.NoOfLicensesTxt.Size = new System.Drawing.Size(100, 20);
            this.NoOfLicensesTxt.TabIndex = 2;
            // 
            // AddSetupCheck
            // 
            this.AddSetupCheck.AutoSize = true;
            this.AddSetupCheck.Location = new System.Drawing.Point(44, 299);
            this.AddSetupCheck.Name = "AddSetupCheck";
            this.AddSetupCheck.Size = new System.Drawing.Size(76, 17);
            this.AddSetupCheck.TabIndex = 4;
            this.AddSetupCheck.Text = "Add Setup";
            this.AddSetupCheck.UseVisualStyleBackColor = true;
            this.AddSetupCheck.CheckedChanged += new System.EventHandler(this.AddSetupCheck_CheckedChanged);
            // 
            // SetupDateTime
            // 
            this.SetupDateTime.Location = new System.Drawing.Point(130, 299);
            this.SetupDateTime.Name = "SetupDateTime";
            this.SetupDateTime.Size = new System.Drawing.Size(200, 20);
            this.SetupDateTime.TabIndex = 5;
            // 
            // ProcessSaleBtn
            // 
            this.ProcessSaleBtn.Location = new System.Drawing.Point(45, 406);
            this.ProcessSaleBtn.Name = "ProcessSaleBtn";
            this.ProcessSaleBtn.Size = new System.Drawing.Size(75, 23);
            this.ProcessSaleBtn.TabIndex = 6;
            this.ProcessSaleBtn.Text = "Process Sale";
            this.ProcessSaleBtn.UseVisualStyleBackColor = true;
            this.ProcessSaleBtn.Click += new System.EventHandler(this.ProcessSaleBtn_Click);
            // 
            // SoftwarePackageList
            // 
            this.SoftwarePackageList.FormattingEnabled = true;
            this.SoftwarePackageList.Location = new System.Drawing.Point(44, 177);
            this.SoftwarePackageList.Name = "SoftwarePackageList";
            this.SoftwarePackageList.Size = new System.Drawing.Size(121, 21);
            this.SoftwarePackageList.TabIndex = 7;
            this.SoftwarePackageList.SelectedIndexChanged += new System.EventHandler(this.SoftwarePackageList_SelectedIndexChanged);
            // 
            // OutPutList
            // 
            this.OutPutList.FormattingEnabled = true;
            this.OutPutList.Location = new System.Drawing.Point(404, 103);
            this.OutPutList.Name = "OutPutList";
            this.OutPutList.Size = new System.Drawing.Size(336, 238);
            this.OutPutList.TabIndex = 8;
            this.OutPutList.SelectedIndexChanged += new System.EventHandler(this.OutPutList_SelectedIndexChanged);
            // 
            // SoftwareSaleIdTxt
            // 
            this.SoftwareSaleIdTxt.Location = new System.Drawing.Point(404, 52);
            this.SoftwareSaleIdTxt.Name = "SoftwareSaleIdTxt";
            this.SoftwareSaleIdTxt.Size = new System.Drawing.Size(81, 20);
            this.SoftwareSaleIdTxt.TabIndex = 9;
            // 
            // GetSoftwareSale
            // 
            this.GetSoftwareSale.Location = new System.Drawing.Point(491, 36);
            this.GetSoftwareSale.Name = "GetSoftwareSale";
            this.GetSoftwareSale.Size = new System.Drawing.Size(75, 23);
            this.GetSoftwareSale.TabIndex = 10;
            this.GetSoftwareSale.Text = "Get";
            this.GetSoftwareSale.UseVisualStyleBackColor = true;
            this.GetSoftwareSale.Click += new System.EventHandler(this.GetSoftwareSale_Click);
            // 
            // DeleteSoftwareSale
            // 
            this.DeleteSoftwareSale.Location = new System.Drawing.Point(492, 66);
            this.DeleteSoftwareSale.Name = "DeleteSoftwareSale";
            this.DeleteSoftwareSale.Size = new System.Drawing.Size(75, 23);
            this.DeleteSoftwareSale.TabIndex = 11;
            this.DeleteSoftwareSale.Text = "Delete";
            this.DeleteSoftwareSale.UseVisualStyleBackColor = true;
            this.DeleteSoftwareSale.Click += new System.EventHandler(this.DeleteSoftwareSale_Click);
            // 
            // UpdateSoftwareSale
            // 
            this.UpdateSoftwareSale.Location = new System.Drawing.Point(12, 12);
            this.UpdateSoftwareSale.Name = "UpdateSoftwareSale";
            this.UpdateSoftwareSale.Size = new System.Drawing.Size(75, 23);
            this.UpdateSoftwareSale.TabIndex = 12;
            this.UpdateSoftwareSale.Text = "Update";
            this.UpdateSoftwareSale.UseVisualStyleBackColor = true;
            this.UpdateSoftwareSale.Click += new System.EventHandler(this.UpdateSoftwareSale_Click);
            // 
            // UpdateSoftwareSaleIdTxt
            // 
            this.UpdateSoftwareSaleIdTxt.Location = new System.Drawing.Point(93, 14);
            this.UpdateSoftwareSaleIdTxt.Name = "UpdateSoftwareSaleIdTxt";
            this.UpdateSoftwareSaleIdTxt.Size = new System.Drawing.Size(100, 20);
            this.UpdateSoftwareSaleIdTxt.TabIndex = 13;
            // 
            // AddSetupRadio
            // 
            this.AddSetupRadio.AutoSize = true;
            this.AddSetupRadio.Location = new System.Drawing.Point(44, 323);
            this.AddSetupRadio.Name = "AddSetupRadio";
            this.AddSetupRadio.Size = new System.Drawing.Size(75, 17);
            this.AddSetupRadio.TabIndex = 14;
            this.AddSetupRadio.TabStop = true;
            this.AddSetupRadio.Text = "Add Setup";
            this.AddSetupRadio.UseVisualStyleBackColor = true;
            this.AddSetupRadio.CheckedChanged += new System.EventHandler(this.AddSetupRadio_CheckedChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(210, 135);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 469);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.AddSetupRadio);
            this.Controls.Add(this.UpdateSoftwareSaleIdTxt);
            this.Controls.Add(this.UpdateSoftwareSale);
            this.Controls.Add(this.DeleteSoftwareSale);
            this.Controls.Add(this.GetSoftwareSale);
            this.Controls.Add(this.SoftwareSaleIdTxt);
            this.Controls.Add(this.OutPutList);
            this.Controls.Add(this.SoftwarePackageList);
            this.Controls.Add(this.ProcessSaleBtn);
            this.Controls.Add(this.SetupDateTime);
            this.Controls.Add(this.AddSetupCheck);
            this.Controls.Add(this.NoOfLicensesTxt);
            this.Controls.Add(this.CustomerNameTxt);
            this.Controls.Add(this.DisplaySales);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button DisplaySales;
        private System.Windows.Forms.TextBox CustomerNameTxt;
        private System.Windows.Forms.TextBox NoOfLicensesTxt;
        private System.Windows.Forms.CheckBox AddSetupCheck;
        private System.Windows.Forms.DateTimePicker SetupDateTime;
        private System.Windows.Forms.Button ProcessSaleBtn;
        private System.Windows.Forms.ComboBox SoftwarePackageList;
        private System.Windows.Forms.ListBox OutPutList;
        private System.Windows.Forms.TextBox SoftwareSaleIdTxt;
        private System.Windows.Forms.Button GetSoftwareSale;
        private System.Windows.Forms.Button DeleteSoftwareSale;
        private System.Windows.Forms.Button UpdateSoftwareSale;
        private System.Windows.Forms.TextBox UpdateSoftwareSaleIdTxt;
        private System.Windows.Forms.RadioButton AddSetupRadio;
        private System.Windows.Forms.ListBox listBox1;
    }
}

